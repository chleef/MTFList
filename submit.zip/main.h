#ifndef _main_h_
#define _main_h_


#include <iostream>
#include <iomanip>
#include <exception>
#include <fstream>
#include <string>
#include <chrono>

#include "Node.h"
#include "MTFList.h"
#include "OrderedList.h"

using namespace std;


#endif
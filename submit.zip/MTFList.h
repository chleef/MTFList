//Header file for MTFList

#ifndef _MTF_LIST_H_
#define _MTF_LIST_H_


#include <iostream>
#include <iomanip>
#include <exception>
#include <fstream>
#include <string>

using namespace std;

#endif